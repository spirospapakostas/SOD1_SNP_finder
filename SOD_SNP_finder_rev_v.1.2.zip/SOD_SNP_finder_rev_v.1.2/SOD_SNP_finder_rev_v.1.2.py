# ---------------------------- Packages ------------------------------- #
import tkinter
from tkinter import *
# ---------------------------- Global variables ------------------------------- #
FONT = ("Courier", 11, "normal")
# ------------------------- Resources and Functions --------------------------- #
nucleotide_options = {
    "A": ["A"],
    "T": ["T"],
    "C": ["C"],
    "G": ["G"],
    "W": ["A", "T"],
    "S": ["C", "G"],
    "M": ["A", "C"],
    "K": ["G", "T"],
    "R": ["A", "G"],
    "Y": ["C", "T"]
}

def suggest_snp():
    SNP_label_entry.delete(0, END)
    SNP_label_entry2.delete(0, END)
    input_sequence = DNA_sequence_entry.get().upper()
    for nucleotide in input_sequence:
        if nucleotide not in nucleotide_options:
            SNP_label_entry.insert(0, "ValueError: Input sequence contains a nucleotide "
                                      "other than the allowed A, T, C, G, W, S, M, K, R, Y")
    try:
        result = [input_sequence[position] if input_sequence[position] == input_sequence[position+1] else
                  "".join(list(set(nucleotide_options[input_sequence[position]]).intersection(nucleotide_options[input_sequence[position+1]])))
                  for position in range(len(input_sequence)-1)]
        result = ["N" if nucleotide == '' else nucleotide for nucleotide in result]
        result_sequence = "".join(result)
        index = result_sequence.find('TGACT')
        SNP_label_entry.insert(0, f"The sequence solution is: {result_sequence}")
        if result_sequence[index+5] == "G":
            resulted_genotype = "G/G"
        elif result_sequence[index+5] == "A":
            resulted_genotype = "A/A"
        elif result_sequence[index+5] == "N":
            resulted_genotype = "A/G"
        SNP_label_entry2.insert(0, f"The genotype for the SNP in question is: {resulted_genotype}")
    except Exception as e:
        SNP_label_entry.insert(0, f"Error: {e}")
# ---------------------------- UI SETUP/PROGRAM ------------------------------- #
# Window
window = Tk()
window.title("SOD_SNP_finder")
window.config(padx=65, pady=20)

# Labels
DNA_sequence_label = Label(pady=-60,
                           text="Paste at the top cell your input DNA sequence as you can read it from the "
                                "chromatogram, that is, in the case of a double peak, e.g. one peak for 'A' "
                                "and one peak for 'T', you use the corresponding IUPAC code for "
                                "degenerate nucleotides (in this example 'W').\n\n"
                                "The program will attempt to correct for a SINGLE deletion between the two strands "
                                "of DNA and infer the actual sequence.\n\nIn case of unresolved outcome, it will use "
                                "the corresponding degenerate code. In case of 'N', a heterozygous nucleotide "
                                "can be assumed. Example sequence: SYKRMYKAARGSS",
                           justify=tkinter.LEFT,
                           wraplength=450)
DNA_sequence_label.grid(row=0, sticky='nsew')

# Entry
DNA_sequence_label_text = tkinter.StringVar(value="Type your input sequence")
DNA_sequence_entry = Entry(width=45, bg='lightgrey', fg="black", textvariable=DNA_sequence_label_text)
DNA_sequence_entry.grid(pady=10, row=1, sticky='nsew')

# Button
SNP_finder_button = Button(text="Find SNP", font=FONT, command=suggest_snp)
SNP_finder_button.grid(row=2)

# Entry
SNP_label_text = tkinter.StringVar(value="Here the sequence solution will be printed")
SNP_label_entry = Entry(width=45, bg='lightgrey', fg="black", textvariable=SNP_label_text)
SNP_label_entry.grid(pady=10, row=3, sticky='nsew')

# Entry
SNP_label_text2 = tkinter.StringVar(value="Here, the SNP solution will be printed (tailored to the given article)")
SNP_label_entry2 = Entry(width=45, bg='lightgrey', fg="black", textvariable=SNP_label_text2)
SNP_label_entry2.grid(pady=10, row=4, sticky='nsew')

# Configure the grid cell to expand when the window is resized
window.columnconfigure(0, weight=1)
window.rowconfigure(0, weight=1)

window.mainloop()
